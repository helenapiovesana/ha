<?php
# app/Model/User.php

App::uses('BlowfishPasswordHasher', 'Controller/Component/Auth');

class Message extends AppModel {
	

	public $validate = [
		
		'mensagem' => [
			'rule' => 'notBlank',
				'message' => 'Digite',
			],
	];

	
}