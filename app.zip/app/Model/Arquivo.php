<?php
# Model/Arquivo.php

class Arquivo extends AppModel {
	public $validate = [
		'title' => [
			// Regra de não-vazio
			'regra-vazio' => [
				'rule' => 'notBlank',
				'message' => 'Preenche alguma coisa!',
			],
			// Tamanho mínimo 5 caracteres
			'regra-tamanho' => [
				'rule' => ['minLength', 5],
				'message' => 'Escreva pelo menos 5 caracteres',
			],
		],
		'commentary' => [
			'regra1' => 'notBlank',
		],
	];

	public function isOwnedBy($post, $user) {
		return $this->field('id', ['id' => $post, 'user_id' => $user]) != false;
	} 
}