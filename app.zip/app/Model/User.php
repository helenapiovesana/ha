<?php
# app/Model/User.php

App::uses('BlowfishPasswordHasher', 'Controller/Component/Auth');

class User extends AppModel {
	public $hasMany = ['Post'];

	public $validate = [
		'username' => [
			'nao-vazio' => [
				'rule' => 'notBlank',
				'message' => 'Insira um nome de usuário',
			],
			'unico' => [
				'rule' => 'isUnique',
				'message' => 'Escolha outro nome.',
				'on' => 'create',
			],
		],
		'password' => [
			'obrigatorio' => [
				'rule' => 'notBlank',
				'message' => 'Vai ficar sem senha?',
			],
		],
		'role' => [
			'valido' => [
				'rule' => ['inList', ['avaliador', 'author']],
				'message' => 'Escolha um papel.',
				'allowEmpty' => false,
			],
		],
		'nascimento' => [
			'rule' => 'notBlank',
				'message' => 'Data de nascimento',
			],
	];

	public function beforeSave($options = []) {
		if (isset($this->data[$this->alias]['password'])) {
			$hasher = new BlowfishPasswordHasher();

			$this->data[$this->alias]['password'] = $hasher->hash($this->data[$this->alias]['password']);
		}
		return true;
	}
}