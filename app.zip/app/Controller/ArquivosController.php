<?php
class ArquivosController extends AppController {

	public $uses = array();
	public $helpers = ['Html', 'Form'];
	public $components = ['Flash', 'Upload'];

	// Função executada antes de qualquer outra coisa
	public function beforeFilter() {
		$this->set('titulo_pagina', 'Postagens');
		parent::beforeFilter();
		$this->Auth->allow('logout', 'view', 'index', 'logout', 'posts', 'add', 'edit', 'upload', 'index');
		//if (isset )
	//return $this->redirect('/users/login');
		//$this->Auth->allow('/users/login');
	}

	public function logout() {
		return $this->redirect($this->Auth->logout());
	}
	
	
	public function index() {
		$postagens = $this->Arquivo->find('all');

		// Envia os dados para a view
		$this->set('titulo_painel', 'Listagem de posts');
		$this->set('posts', $postagens);
		//$this->set('users', $user);
	}

	public function upload(){

		// Verifica se está recebendo formulário (post)
		if ($this->request->is('post')) {

			$this->Arquivo->create();

			foreach ($this->request->data['Arquivo']['uploadfile'] as $file) {
				$this->request->data['Arquivo']['filename'] = $file ['name'];
				$this->request->data['Arquivo']['tamanho'] = $file ['size'];
				$this->request->data['Arquivo']['status'] = 'analise'; 
			}

			$salvar = $this->Arquivo->save($this->request->data);
		
			$this->Upload->upload($this->request->data['Arquivo']['uploadfile']);

			return $this->redirect(['controller' => 'arquivos', 'action' => 'index']);
		}
	}

	public function download($file){
		$this->response->file(
			APP.'arquivo'.DS.$file,
			array('download' => true , 'name' => $file)
			);
		$this->render(false);
	}

	public function isAuthorized($user){
		if($this->action == 'download'){
			return true;
		}

		return parent::isAuthorized($user);
	}

	public function status(){
		
		$postagens = $this->Arquivo->find('all');

		// Envia os dados para a view
		$this->set('titulo_painel', 'Listagem de posts');
		$this->set('posts', $postagens);
		//$this->set('users', $user);
		
		
	/*if ($this->request->is('post')){
			
			$posts = $this->Arquivo->find('all');

		
		$this->set('posts', $posts);
			
			
			//debug ($this->data);
			//debug($this->request->data);
			$id = $this->Auth->user('id');

			//$hasher = new BlowfishPasswordHasher();

			//$senha = $hasher->hash($this->data['User']['password']);
			//$formacao = ($this->data['User']['formacao']);
			$status = $this->request->data['Arquivo']['status']; 

			$this->User->updateAll(['Arquivo.status'=> "'$status'" ], ['User.id' => $id] );
			
			

			return $this->redirect(['controller' => 'arquivos', 'action' => 'index']);
	} 
	
*/	}
 
public function aprovar($id){
			
		
		$post = $this->Arquivo->findById($id);
		$this->Arquivo->id = $id;
		///$id = $this->request->data(['Arquivo']['id']);
		//debug ($id); 
		$aprovar= 'aprovado';
			
		$this->Arquivo->updateAll(['Arquivo.status'=> "'$aprovar'" ], ['Arquivo.id' => $id] );
		return $this->redirect(['controller' => 'arquivos', 'action' => 'status']);
	
	
}




public function reprovar($id){
			
		$post = $this->Arquivo->findById($id);
		$this->Arquivo->id = $id;
			
		//$id = $this->request->data(['Arquivo']['id']);
		//debug ($id); 
		$reprovar= 'reprovado';
			
		$this->Arquivo->updateAll(['Arquivo.status'=> "'$reprovar'" ], ['Arquivo.id' => $id] );
		return $this->redirect(['controller' => 'arquivos', 'action' => 'status']);
	
	
}
 
 
 
}