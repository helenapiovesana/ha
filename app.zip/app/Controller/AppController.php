<?php

App::uses('Controller', 'Controller');
//Router::connect( array('controller' => 'users', 'action' => 'login'));
//return $this->redirect(['controller' => 'arquivos', 'action' =>'index']);
				
class AppController extends Controller {
	public $components = [
		'Flash',
		'Auth'=> [
			'loginRedirect' => [
				'controller' => 'arquivos',
				'action' => 'index',
			],
			'logoutRedirect' => [
				'controller' => 'pages',
				'action' => 'display',
				'home',
			],
			'authenticate' => [
				'Form' => [
					'passwordHasher' => 'Blowfish',
				],
			],
			'authorize' => ['Controller'],
		],
	];

	public function beforeFilter() {
		// Permite algumas ações
		$this->Auth->allow('logout', 'view', 'index', 'logout', 'posts', 'add', 'edit', 'upload');

		// Verifica usuário autenticado
		$this->set('usuarioAutenticado', $this->Auth->user());
		 //return $this->redirect(
        //['controller' => 'users', 'action' => 'login']
		//return $this->redirect('/users/login');
    //);
		
		
		// para o menu ......  if ($usuarioAutenticado['role'] == 'avaliador')
	}

	// Faz a verificação de privilégios de acesso
	public function isAuthorized($user) {
		// Verifica se é o admin - ele pode tudo! :-O
		if (isset($user['role']) && $user['role'] == 'avaliador' or $user['role'] == 'author') {
			return true;
		}

		// Se não entrar no IF, não é admin
		return false;
	}

}
