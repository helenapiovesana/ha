<?php
# app/Controller/UsersController.php
App::uses('BlowfishPasswordHasher', 'Controller/Component/Auth');

class UsersController extends AppController {

	public function beforeFilter() {
		$this->set('titulo_pagina', 'Postagens');
		parent::beforeFilter();
	}



	public function index() {
		$this->User->recursive = 0;
		$this->set('users', $this->paginate());
	}

	
	
	
	public function login() {
		//Troca layout
		//$this->User='login';
		
		$this->Auth->user('id');
		
		if ($this->request->is('post')) {
			// Verifica se a pessoa se autenticou
			if ($this->Auth->login()) {
				
				
				if ($this->Auth->user('role') == 'autor'){
				
				return $this->redirect(['controller' => 'arquivos', 'action' =>'index']);
				
				}
				
				if ($this->Auth->user('role') == 'avaliador'){
				
				return $this->redirect(['controller' => 'arquivos', 'action' =>'index']);
				
				}
				
			}
			$this->Flash->error('Usuário ou senha inválidos!');
		}
	}


	public function logout() {
		return $this->redirect($this->Auth->logout());
	}

	public function add() {
		// Verifica se é pra gravar
		if ($this->request->is('post')) {
			$this->User->create();

			// Tenta salvar no banco
			/* $this->User->save() salva no banco
			$this->request->data são os dados do formulário
			*/
			if ($this->User->save($this->request->data)) {
				// Se entrar no IF quer dizer que salvou
				$this->Flash->success('Usuário salvo com sucesso.');
				return $this->redirect(['action' => 'index']);
			}
			// Se não entrou no IF, deu erro!
			$this->Flash->error('Usuário não foi salvo.');
		}
	}

	public function edit(){
		if ($this->request->is('post')){
			//debug($this->request->data);
			$id = $this->Auth->user('id');

			$hasher = new BlowfishPasswordHasher();

			$senha = $hasher->hash($this->data['User']['password']);

			$this->User->updateAll(['User.password'=> "'$senha'"], ['User.id' => $id] );

			return $this->redirect(['controller' => 'arquivos', 'action' => 'index']);
		}
	}

	// Mostra os posts de um determinado usuário
	public function posts($id) {
		$user = $this->User->findById($id);
		$this->set('user', $user);
	}

}