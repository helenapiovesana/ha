<?php
# app/Controller/UsersController.php
App::uses('BlowfishPasswordHasher', 'Controller/Component/Auth');

class AmigosController extends AppController {

	public function beforeFilter() {
		$this->set('titulo_pagina', 'Postagens');
		parent::beforeFilter();
		$this->Auth->allow('logout', 'view', 'index', 'logout', 'posts', 'add', 'edit', 'upload', 'amigos/index');
		//return $this->redirect('/users/login');
	}



	public function index() {
		$this->User->recursive = 0;
		$this->set('users', $this->paginate());
		//return $this->redirect('/users/login');
	}

	
	
	
	public function login() {
		$this->Auth->user('id');
		
		if ($this->request->is('post')) {
			// Verifica se a pessoa se autenticou
			if ($this->Auth->login()) {
				
				return $this->redirect(['controller' => 'arquivos', 'action' =>'index']);
				
		
				
				
			}
			$this->Flash->error('Usuário ou senha inválidos!');
		}
	}


	public function logout() {
		return $this->redirect($this->Auth->logout());
	}

	public function add() {
		// Verifica se é pra gravar
		if ($this->request->is('post')) {
			$this->User->create();
//debug ($this->request->data); 
			// Tenta salvar no banco
			/* $this->User->save() salva no banco
			$this->request->data são os dados do formulário
			*/
			if ($this->User->save($this->request->data)) {
				// Se entrar no IF quer dizer que salvou
				$this->Flash->success('Usuário salvo com sucesso.');
				return $this->redirect(['action' => 'index']);
			}
			// Se não entrou no IF, deu erro!
		
		$this->Flash->error('Usuário não foi salvo.');
		}
	}

	public function seguir($id){
		//if ($this->request->is('post')){
			$this->Amigo->create();
			//$amigos = $this->Amigo->findAllById($id);
			//debug ($amigos); 
			
			
		$idlogado = $this->Auth->User('username');
		
		$tudo = array() ;
		$tudo['Amigo']['seguidor'] = ($idlogado);
		$tudo['Amigo']['seguindo'] =  ($id); 
		
		$this->Amigo->save($tudo);
			
			//debug ($tudo);
			
		return $this->redirect(['controller' => 'amigos', 'action' => 'seguindo']);
			
			
			//}
	}
	
	
	public function seguidores(){
		
		$id = $this->Auth->User('username');
		//debug ($id);
		$amigos = $this->Amigo->findAllBySeguindo($id);
		$this->set('amigos', $amigos);
		
		
		//$nome= $this->User->findById($amigos['seguindo']);
		//$this->set('nomes', $nomes);
		//$this->set('amigos', $this->paginate());
		
	}
	
	
	public function seguindo(){
		$id = $this->Auth->User('username');
		$amigos = $this->Amigo->findAllBySeguidor($id);
		$this->set('amigos', $amigos);
		
		
		//$nome= $this->User->findById($amigos['seguidor']);
		//$this->set('nomes', $nomes);
		
		
		//return ($this->redirect(['controller' => 'amigos', 'action' => 'seguindo']));
		//$this->set('amigos', $this->paginate());
	}

			
	
			
			
			
		
	// Mostra os posts de um determinado usuário
	public function posts($id) {
		$user = $this->User->findById($id);
		$this->set('user', $user);
		return $this->redirect('/users/login');
	}

}