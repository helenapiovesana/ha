<?php
# app/Controller/UsersController.php
App::uses('BlowfishPasswordHasher', 'Controller/Component/Auth');

class MessagesController extends AppController {
	public $helpers = array('Session');
	public $uses = array ('Message', 'User'); 
	public $components = array('Session');
	
	public function beforeFilter() {
		$this->set('titulo_pagina', 'Postagens');
		parent::beforeFilter();
	}

	
	
	public function todas(){
		
		$this->User->create();
		$id = $this->Auth->User('id');
		$idrecebe = $this->Message->findByIdrecebe($id);
		$this->set('messages', $idrecebe);
		
	}


	public function index($id = 1) {
		
		$this->Message->recursive = 0;
		$this->set('messages', $this->paginate());
		$this->Session->write('idmensagem',$id);
			}

	

	public function logout() {
		return $this->redirect($this->Auth->logout());
	}

	public function add() {
		
		
			
			$this->User->create();
			$id = $this->Auth->User('id');
			
			$this->Message->create();
			
			$tudo = array();
			$tudo['Message']['idmanda'] = $id;
			$tudo['Message']['idrecebe'] =  $this->Session->read('idmensagem');
			$tudo['Message']['mensagem'] = $this->request->data['Message']['mensagem']; 
			
			$this->Message->save($tudo); 
	
			$this->Flash->success('Mensagem salva com sucesso.');
			return $this->redirect(['controller'=> 'messages', 'action' => 'index']);
			
		
	}

	public function edit(){
		if ($this->request->is('post')){
			//debug($this->request->data);
			$id = $this->Auth->user('id');

			$hasher = new BlowfishPasswordHasher();

			$senha = $hasher->hash($this->data['User']['password']);

			$this->User->updateAll(['User.password'=> "'$senha'"], ['User.id' => $id] );

			return $this->redirect(['controller' => 'arquivos', 'action' => 'index']);
		}
	}

	// Mostra os posts de um determinado usuário
	public function posts($id) {
		$user = $this->User->findById($id);
		$this->set('user', $user);
	}

}